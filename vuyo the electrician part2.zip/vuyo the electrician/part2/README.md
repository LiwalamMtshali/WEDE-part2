# Vuyo the Electrician Website

This is a professional website for Vuyo the Electrician, showcasing services, testimonials, contact information, and more.

## Features
- Home page with images and a visible offer marquee
- About page with business story and mission
- Services page with attractive, readable service list and booking button
- Contact page with form and WhatsApp link
- Testimonial page with styled reviews and images
- Consistent rosybrown background and modern navigation

## How to Use
1. Open any HTML file (e.g., `Home.html`) in your browser to view the site.
2. Edit content in VS Code and save your changes.
3. Images should be placed in the `images` folder for best results.

## Folder Structure
```
part2/
  Home.html
  About.html
  Services.html
  Contact.html
  testimonial.html
  index.html
  css/
    styles.css
  images/
    th.jpg
    v 1.jpg
    v 2.jpg
    v 3.jpg
    v6.webp
  documents/
    WEDE Proposal.docx
```

## Contact
For any queries, use the contact form or WhatsApp link on the Contact page.

---
Created by Liwalam Mtshali, 2025.
